
## Current folder contains

**from [jagannatharjun's ](https://github.com/jagannatharjun/qbt-theme/blob/master/material/resources.qrc)**
- resources.qrc